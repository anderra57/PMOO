package packproiektua;

public class Protagonista extends Pertsonaia{

	private int x;
	private int y;
	private int ind;
	private int intel;
	private int car;
	private ListaAkzioak listaA;
	private Inbentarioa listaI;
	
	private Protagonista nireProtagonista = null;
	
	private Protagonista(String pIzena,int pAtq,int pDef,int pX,int pY,int pInd,int pIntel,int pCar){
		super(pAtq,pDef,pIzena);

		this.listaA=new ListaAkzioak();
		this.listaI=Inbentarioa.getNireInbentarioa();
	}
	
	public Protagonista nireProtagonista(){
		if(nireProtagonista == null){
			nireProtagonista = new Protagonista();
		}
		return nireProtagonista;
	}
	
	public void pertsonaiaEguneratu(int pMina){
		super.pertsonaiaEguneratu(pMina-intel);
	}
	
	public void objetuaErabili(int pObjIz){
		
	}
	
	public void posizioazAldatu(pX:int, pY:int){
		
	}
	
	public void hasierakoPosizioa(){
		int egoera= Egoera.egungoEgoeraLortu();
		//if (egoera==1)
		//if (egoera==2)
		//if (egoera==3)
	}
}