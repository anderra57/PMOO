package packproiektua;

public class Gordelekua {

	private int x;
	private int y;
	
	public Gordelekua(int pX, int pY){
		this.x = pX;
		this.y = pY;
	}
}
