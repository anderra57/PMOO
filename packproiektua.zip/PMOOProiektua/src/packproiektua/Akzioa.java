package packproiektua;

public class Akzioa {
	private String izena;
	
	public Akzioa(String pIzena){
		this.izena = pIzena;
	}
	public void akzioaBurutu(){
		
	}
}
