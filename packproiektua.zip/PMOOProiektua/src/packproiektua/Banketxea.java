package packproiektua;

public class Banketxea extends Egoera{
	private int idEgoera;
	
	public Banketxea(String pDeskribapena, ListaAkzioak pLista){
		super(pDeskribapena, pLista);
		this.idEgoera=3;
	}
	public void eszenatokiaInprimatu(){
		
	}
}
