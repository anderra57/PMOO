package packproiektua;
import java.util.Random;


public class Etsaia {
	
	private int bizitza;
	private int atq;
	
	public Etsaia(int pAtq){
		this.atq = pAtq;
		this.bizitza = 100;
	}
	
	public void eraso(int pAtq){
		Protagonista.class.
		
	}
}
