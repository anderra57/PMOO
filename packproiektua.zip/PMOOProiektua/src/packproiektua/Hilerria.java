package packproiektua;

public class Hilerria extends Egoera{
	
	public Hilerria(String pDeskribapena, ListaAkzioak pLista){
		super(pDeskribapena, pLista);
		this.idEgoera=2;
	}
	public void eszenatokiaInprimatu(){
		
	}
}
