package packproiektua;

import java.util.ArrayList;
import java.util.Iterator;

public class ListaEtsaiak {
	
	private ArrayList<Etsaia> lista;
	
	public ListaEtsaiak(){
		this.lista = new ArrayList<Etsaia>();
	}
	public Etsaiak EtsaiakAtera(){
		
	}
}
