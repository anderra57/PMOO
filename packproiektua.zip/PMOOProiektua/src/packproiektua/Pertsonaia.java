package packproiektua;

public abstract class Pertsonaia {
	private int atq;
	private int def;
	private int pv;
	private String izena;
	
	public Pertsonaia(int pAtq, int pDef, String pIzena){
		this.atq=pAtq;
		this.def=pDef;
		this.pv=100;
		this.izena=pIzena;
	}
	public void pertsonaiaEguneratu(int pMina){
		this.pv=this.pv-(pMina-def);
	}
	public boolean pertsonaiaBerdina(Pertsonaia pPertsonaia){
		return this.equals(pPertsonaia);
	}
}
