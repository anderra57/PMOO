package proiektua;

public class Nagusia {
    public static void main(String[] args) {
    	//matrix
        Saloia matrize = new Saloia();
        matrize.eszenatokiaInprimatu();
        
}
